# URI Insights - Signal Generation & Scraper Diagnostic Package

## 🎯 Purpose
This package contains the essential files for diagnosing and fixing issues with our social media scraping, job board scraping, and buying signal detection systems.

---

## 🚨 **CRITICAL ISSUES TO INVESTIGATE**

### **Issue 1: Twitter Apify Scraper Rate Limiting**
**Problem:**
- Twitter Apify scraper keeps hitting rate limits
- Results in fetching **stale posts** or **no posts at all**
- Impacts real-time buying signal detection

**Affected File:**
- `services/OpenAIApifyTwitterService.py`

**Questions:**
1. How can we implement better rate limit handling?
2. Should we implement exponential backoff?
3. Can we cache results more intelligently?
4. Are we making too many requests per scan?
5. Should we switch to a different Apify actor for Twitter?
6. Can we implement request queuing/throttling?

---

### **Issue 2: LinkedIn & Jobberman Job Scrapers Fetching Irrelevant Posts**
**Problem:**
- Job board scrapers return posts **NOT related to keywords provided**
- Appears to be fetching **cached/stale job posts** instead of fresh, relevant ones
- Wastes AI analysis credits on irrelevant jobs

**Affected Files:**
- `services/ApifyLinkedInJobsService.py`
- `services/JobBoardParameterHelper.py` (if exists)
- `services/ConversationalLeadJobService.py`

**Questions:**
1. Are we passing keywords correctly to the Apify actors?
2. Is the actor filtering by keywords or just location?
3. Should we implement **client-side keyword filtering** after fetching?
4. Are the Apify actors we're using outdated/broken?
5. What **alternative job board scrapers** exist on Apify?
6. Can we implement **keyword relevance scoring** before sending to AI?

---

### **Issue 3: Social Media Filtering - Location & Time**
**Problem:**
- Cannot efficiently filter by **location** or **time of post** at the Apify scraper level
- Currently filtering happens at **intent analysis level** (after fetching)
- Wasting API calls and time fetching irrelevant posts

**Affected Files:**
- `services/OpenAIApifyTwitterService.py`
- `services/ApifyLinkedInPostScraperService.py`
- `services/LazarusMonitoringService.py`

**Questions:**
1. **Can Apify actors filter by location/time natively?**
   - Check actor parameters
   - Review API documentation
2. **If Apify-level filtering is NOT possible:**
   - How can we improve **post-fetch filtering**?
   - Should we filter BEFORE sending to AI analysis?
   - Can we implement **smarter caching** based on location/time?
3. **Alternative solutions:**
   - Use different Apify actors with better filtering?
   - Implement **multi-stage filtering pipeline**?
   - Add **location extraction** from post content?
   - Add **timestamp validation** before AI analysis?

---

### **Issue 4: Intent Analysis Efficiency**
**Problem:**
- Currently analyze ALL fetched posts with AI
- No pre-filtering based on relevance
- Expensive AI API calls on irrelevant content

**Affected Files:**
- `services/LazarusMonitoringService.py` (see `_detect_buying_intent()`)
- `services/AIService.py`
- `prompts/ai_prompt.py`

**Questions:**
1. Can we implement **keyword pre-filtering** before AI analysis?
2. Should we use **cheaper models** for initial relevance screening?
3. Can we implement **rule-based filters** to skip obvious irrelevant posts?
4. Should we implement **post scoring/ranking** to prioritize which posts to analyze?

---

## 📂 **File Structure & Purpose**

```
DIAGNOSTIC_PACKAGE/
│
├── services/
│   ├── OpenAIApifyTwitterService.py         ← Twitter scraping with Apify
│   ├── ApifyLinkedInJobsService.py          ← LinkedIn job scraping
│   ├── ApifyLinkedInPostScraperService.py   ← LinkedIn post scraping
│   ├── ApifyGoogleSearchService.py          ← Google search for funding news
│   ├── LazarusMonitoringService.py          ← Main monitoring orchestration
│   ├── AIService.py                         ← AI analysis & signal detection
│   ├── ConversationalLeadJobService.py      ← Conversational lead processing
│   └── JobBoardParameterHelper.py           ← (If exists) Job search optimization
│
├── helpers/
│   ├── apollo_helper.py                     ← Apollo API integration
│   └── social_url_helper.py                 ← Social URL parsing
│
├── prompts/
│   └── ai_prompt.py                         ← AI prompts for signal detection
│
├── domain/
│   └── lazarus_schema.py                    ← Data models for Lazarus
│
└── README.md                                 ← This file
```

---

## 🔍 **How Each Service Works**

### **1. OpenAIApifyTwitterService.py**
- Uses Apify actor: `apidojo/tweet-scraper` or similar
- Fetches tweets based on keyword queries
- **Issue**: Rate limiting causes failures
- **Current query format**: `"keyword1 OR keyword2"`

### **2. ApifyLinkedInJobsService.py**
- Uses Apify actor: `bebity/linkedin-jobs-scraper`
- Fetches job postings from LinkedIn
- **Issue**: Returns irrelevant jobs not matching keywords
- **Parameters**: `keyword`, `location`, `publishedAt`, `maxItems`

### **3. ApifyLinkedInPostScraperService.py**
- Uses Apify actor: `supreme_coder/linkedin-post`
- Fetches user posts/activity from LinkedIn profiles
- **Parameters**: `urls`, `deepScrape`, `limitPerSource`
- **Issue**: No location/time filtering

### **4. LazarusMonitoringService.py**
- **Main orchestration service**
- Method `scan_focus_contacts()`: Scans individuals for buying signals
- Method `_fetch_batch_tweets()`: Fetches Twitter posts (Origami method)
- Method `_fetch_linkedin_posts()`: Fetches LinkedIn posts
- Method `_detect_buying_intent()`: AI analysis for signals
- **Issue**: No pre-filtering, analyzes everything

### **5. AIService.py**
- Handles all AI/LLM interactions
- Uses OpenAI/Anthropic for analysis
- **Issue**: Expensive to run on irrelevant content

---

## 🎯 **Key Questions for Claude Opus**

### **Rate Limiting & Reliability**
1. How to implement retry logic with exponential backoff?
2. How to detect and handle rate limits gracefully?
3. Should we implement request queuing?
4. What are better Twitter scraping alternatives?

### **Relevance & Filtering**
1. How to implement keyword matching BEFORE AI analysis?
2. Can we extract location from post text content?
3. How to validate post timestamps before analysis?
4. Should we implement a relevance scoring system?

### **Performance & Cost**
1. How to reduce AI API calls on irrelevant content?
2. Can we use cheaper models for initial screening?
3. Should we implement multi-stage analysis pipeline?
4. How to improve caching strategy?

### **Alternative Solutions**
1. Better Apify actors for Twitter scraping?
2. Better Apify actors for job board scraping?
3. Alternative to Apify entirely?
4. Custom scraping solutions vs. Apify?

---

## 🛠️ **Current Flow (Problematic)**

```
1. User triggers scan
   ↓
2. Fetch ALL posts from Apify (no filtering)
   ↓  ← ISSUE: Rate limits, stale data, irrelevant posts
3. Send ALL posts to AI for analysis
   ↓  ← ISSUE: Expensive, wasteful on irrelevant content
4. AI detects buying signals
   ↓
5. Create alerts
```

---

## 💡 **Desired Flow (Optimized)**

```
1. User triggers scan
   ↓
2. Fetch posts with SMART FILTERING at Apify level
   - Filter by time (last 7 days)
   - Filter by location (if possible)
   - Filter by engagement (high quality posts)
   ↓
3. PRE-FILTER fetched posts client-side
   - Keyword matching
   - Timestamp validation
   - Location extraction from content
   ↓
4. Send ONLY RELEVANT posts to AI
   ↓
5. AI detects buying signals (higher accuracy)
   ↓
6. Create high-quality alerts
```

---

## 📊 **Metrics to Track**

1. **Fetch Success Rate**: % of successful Apify scrapes
2. **Post Relevance Rate**: % of posts matching keywords
3. **AI Analysis Cost**: $ spent per scan
4. **Signal Detection Rate**: % of scans finding signals
5. **False Positive Rate**: % of irrelevant alerts
6. **Average Scan Time**: Seconds per scan

---

## 🔧 **Configuration Files Needed (Not Included)**

- `.env` - API keys (APIFY_API_TOKEN, OPENAI_API_KEY)
- `app/core/config.py` - Settings configuration

---

## 📝 **Instructions for Claude Opus**

**Please analyze these files and:**

1. ✅ **Identify root causes** of rate limiting, irrelevant results, and inefficiency
2. ✅ **Suggest specific code changes** to fix each issue
3. ✅ **Recommend alternative Apify actors** if current ones are problematic
4. ✅ **Design improved filtering pipeline** for location/time/relevance
5. ✅ **Propose cost reduction strategies** for AI analysis
6. ✅ **Provide implementation plan** with priority order

**Focus Areas:**
- Rate limit handling in `OpenAIApifyTwitterService.py`
- Keyword filtering in `ApifyLinkedInJobsService.py`
- Pre-filtering logic in `LazarusMonitoringService.py`
- AI prompt optimization in `ai_prompt.py`

---

## 🚀 **Expected Deliverables from Analysis**

1. **Root Cause Analysis Report**
2. **Specific Code Fixes** (with diffs)
3. **Alternative Actor Recommendations**
4. **Improved Architecture Diagram**
5. **Implementation Priority List**
6. **Cost/Performance Projections**

---

## 📧 **Context**

- **System**: Lazarus Protocol - CRM Lead Resurrection
- **Purpose**: Monitor dead leads for buying signals
- **Tech Stack**: Python (FastAPI), Apify, OpenAI/Anthropic
- **Scale**: Scanning 100s of contacts weekly
- **Budget**: Need to minimize API costs while maximizing signal quality

---

**Last Updated**: January 2025
**Package Version**: 1.0
**Prepared For**: Claude Opus Diagnostic Analysis

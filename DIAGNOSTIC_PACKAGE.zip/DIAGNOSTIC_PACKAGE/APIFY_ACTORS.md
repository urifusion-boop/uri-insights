# Apify Actors Currently Used

## 🎯 **Current Actors in Production**

### **1. Twitter/X Scraping**
**Actor**: `apidojo/tweet-scraper` (or similar - check OpenAIApifyTwitterService.py)
**File**: `services/OpenAIApifyTwitterService.py`
**Purpose**: Fetch tweets based on keyword queries
**Status**: ⚠️ **PROBLEMATIC** - Rate limiting issues

**Current Parameters:**
- `keyword`: Search query (e.g., "technology OR AI")
- `max_tweets`: Maximum tweets to fetch
- `analyze_sentiment`: Boolean for sentiment analysis

**Issues:**
- Rate limits frequently exceeded
- Returns stale/old tweets
- Sometimes returns no results

**Alternative Actors to Consider:**
- `clockworks/free-twitter-scraper`
- `lexis/twitter-scraper`
- `curious_coder/twitter-scraper-new`

---

### **2. LinkedIn Jobs Scraping**
**Actor**: `bebity/linkedin-jobs-scraper`
**File**: `services/ApifyLinkedInJobsService.py`
**Purpose**: Fetch job postings from LinkedIn
**Status**: ⚠️ **PROBLEMATIC** - Irrelevant results

**Current Parameters:**
```python
{
    "keyword": "DevOps Engineer",
    "maxItems": 15,
    "publishedAt": "Past Month",
    "location": "Worldwide",
    "proxy": {
        "useApifyProxy": True,
        "apifyProxyGroups": ["RESIDENTIAL"]
    }
}
```

**Issues:**
- Returns jobs NOT matching keywords
- Fetches cached/stale job posts
- Location filtering doesn't work well

**Alternative Actors to Consider:**
- `curious_coder/linkedin-jobs-scraper`
- `bebity/linkedin-job-url-scraper` (different approach)
- Custom solution using LinkedIn API (if available)

---

### **3. LinkedIn Posts Scraping** ✅
**Actor**: `supreme_coder/linkedin-post`
**File**: `services/ApifyLinkedInPostScraperService.py`
**Purpose**: Fetch LinkedIn posts/activity from user profiles
**Status**: ✅ **WORKING** - Recently implemented

**Current Parameters:**
```python
{
    "deepScrape": True,
    "limitPerSource": 10,
    "rawData": False,
    "urls": ["https://linkedin.com/in/username", ...]
}
```

**Issues:**
- No location filtering
- No time filtering (can't get only last 7 days)
- Returns ALL posts up to limit

**Possible Improvements:**
- Check if actor supports `datePosted` parameter
- Check if actor supports `location` parameter
- Implement client-side filtering after fetch

---

### **4. Google Search (for Funding News)**
**Actor**: (Unknown - check ApifyGoogleSearchService.py)
**File**: `services/ApifyGoogleSearchService.py`
**Purpose**: Search Google for funding/pivot news
**Status**: ❓ **UNKNOWN**

**Typical Parameters:**
- `dork_query`: Google dork query
- `max_results`: Number of results
- `country_code`: Geographic targeting

---

## 🔍 **How to Find Better Actors**

### **Apify Store Search:**
1. Go to: https://apify.com/store
2. Search for: "twitter scraper", "linkedin jobs", etc.
3. Filter by:
   - ⭐ Rating (4+ stars)
   - 📊 Runs (high usage = reliable)
   - 📅 Last updated (recent = maintained)

### **Key Metrics to Check:**
- **Success Rate**: Should be >95%
- **Average Runtime**: Faster is better
- **Cost per Run**: Compare pricing
- **Documentation**: Well-documented = easier to use

---

## 💡 **Recommended Actor Requirements**

### **For Twitter:**
✅ Supports advanced search queries
✅ Can filter by date range
✅ Has rate limit handling
✅ Returns structured JSON
✅ Supports location filtering
✅ Recently maintained (updated in last 3 months)

### **For LinkedIn Jobs:**
✅ Accurate keyword matching
✅ Date filtering (last 7/30 days)
✅ Location filtering
✅ Experience level filtering
✅ Returns fresh results (not cached)
✅ Company filtering

### **For LinkedIn Posts:**
✅ Date range filtering
✅ Location extraction
✅ Engagement metrics (likes, comments)
✅ Deep scraping option
✅ Batch URL support

---

## 🚨 **Action Items**

1. **Test Alternative Twitter Actors**:
   - Create test script to compare actors
   - Measure: success rate, speed, relevance
   - Pick winner based on metrics

2. **Test Alternative Job Scrapers**:
   - Compare keyword accuracy
   - Test with various job titles
   - Verify freshness of results

3. **Review Actor Documentation**:
   - Check for hidden parameters
   - Look for filtering options we're not using
   - Contact actor developers if needed

4. **Implement Fallback Logic**:
   - If Actor A fails → try Actor B
   - If Actor B fails → use cached data
   - Log failures for monitoring

---

## 📊 **Actor Comparison Template**

Use this to evaluate alternatives:

| Metric | Current Actor | Alternative 1 | Alternative 2 |
|--------|--------------|---------------|---------------|
| Success Rate | ? | ? | ? |
| Avg Runtime | ? | ? | ? |
| Cost per 1K | ? | ? | ? |
| Keyword Accuracy | ? | ? | ? |
| Date Filtering | ❌ | ? | ? |
| Location Filtering | ❌ | ? | ? |
| Last Updated | ? | ? | ? |
| Documentation | ? | ? | ? |
| Support | ? | ? | ? |

---

## 🔗 **Useful Links**

- **Apify Store**: https://apify.com/store
- **Apify Docs**: https://docs.apify.com/
- **Python Client**: https://docs.apify.com/api/client/python
- **Actor Development**: https://docs.apify.com/academy

---

**Note**: Check the actual actor IDs in the Python files - they might have changed since this document was created.

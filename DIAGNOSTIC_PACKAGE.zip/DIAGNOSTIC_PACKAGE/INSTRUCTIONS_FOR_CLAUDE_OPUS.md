# 📦 Instructions for Claude Opus Analysis

## 🎯 **What We Need from You**

We're experiencing critical issues with our Lazarus Protocol signal generation system. This package contains all the essential code for you to analyze and provide solutions.

---

## 🚨 **The Problems (Priority Order)**

### **1. Twitter Rate Limiting (CRITICAL)**
**File**: `services/OpenAIApifyTwitterService.py`

Our Twitter scraper constantly hits rate limits, causing:
- Failed scans (no data returned)
- Stale tweets (old data)
- Inconsistent results

**We need:**
- Robust retry logic with exponential backoff
- Better rate limit detection and handling
- Alternative Twitter scraping solutions
- Request queuing/throttling implementation

---

### **2. Irrelevant Job Board Results (HIGH)**
**Files**:
- `services/ApifyLinkedInJobsService.py`
- `services/JobBoardParameterHelper.py`

Job scrapers return posts that DON'T match our keywords:
- Seems to fetch cached/stale jobs
- LinkedIn jobs not matching search criteria
- Jobberman same issue

**We need:**
- Fix keyword matching logic
- Implement client-side relevance filtering
- Alternative job board scraper recommendations
- Keyword relevance scoring system

---

### **3. No Location/Time Filtering (HIGH)**
**Files**:
- `services/OpenAIApifyTwitterService.py`
- `services/ApifyLinkedInPostScraperService.py`

Cannot filter by location or post time at scraper level:
- Fetching posts from wrong locations
- Getting old posts (weeks/months old)
- Wastes AI analysis on irrelevant content

**We need:**
- Check if Apify actors support location/time parameters
- Implement efficient post-fetch filtering
- Location extraction from post content
- Timestamp validation before AI analysis

---

### **4. Inefficient AI Analysis (MEDIUM)**
**File**: `services/LazarusMonitoringService.py`

We send ALL posts to AI without pre-filtering:
- Expensive (wasting credits on irrelevant posts)
- Slow (analyzing everything)
- Lower accuracy (too much noise)

**We need:**
- Pre-filtering pipeline before AI
- Keyword matching before AI analysis
- Multi-stage analysis (cheap model → expensive model)
- Post scoring/ranking system

---

## 📂 **Files Included (15 total, 368KB)**

```
services/ (7 files)
├── OpenAIApifyTwitterService.py      - Twitter scraping ⚠️ BROKEN
├── ApifyLinkedInJobsService.py       - LinkedIn jobs ⚠️ BROKEN
├── ApifyLinkedInPostScraperService.py - LinkedIn posts ✅ OK
├── LazarusMonitoringService.py       - Main orchestration
├── AIService.py                      - AI analysis
├── ConversationalLeadJobService.py   - Lead processing
└── ApifyGoogleSearchService.py       - Google search

helpers/ (2 files)
├── apollo_helper.py                  - Apollo API
└── social_url_helper.py              - URL parsing

prompts/ (1 file)
└── ai_prompt.py                      - AI prompts for signals

domain/ (2 files)
├── lazarus_schema.py                 - Data models
└── lead_schema.py                    - Lead models

docs/ (3 files)
├── README.md                         - Main overview
├── APIFY_ACTORS.md                   - Actor details
└── INSTRUCTIONS_FOR_CLAUDE_OPUS.md   - This file
```

---

## 🔍 **What to Focus On**

### **1. Rate Limit Handling**
- Review `OpenAIApifyTwitterService.py`
- Look for retry logic (or lack thereof)
- Check error handling
- Suggest improvements

### **2. Keyword Filtering**
- Review `ApifyLinkedInJobsService.py`
- Check how keywords are passed to Apify
- Look for filtering logic after fetch
- Suggest relevance scoring

### **3. Pre-Processing Pipeline**
- Review `LazarusMonitoringService.py`
- Look at `_fetch_batch_tweets()` and `_fetch_linkedin_posts()`
- Find where posts go directly to AI
- Suggest filtering before AI

### **4. AI Prompt Optimization**
- Review `prompts/ai_prompt.py`
- Check `ANALYZE_BUYING_SIGNALS` prompt
- Suggest improvements for accuracy

---

## 📋 **Deliverables We Need**

### **1. Root Cause Analysis**
For each issue:
- What's causing it?
- Why is the current approach failing?
- What are we missing?

### **2. Specific Code Fixes**
Provide:
- Exact code changes (with line numbers)
- New functions to add
- Refactoring suggestions

### **3. Alternative Solutions**
Recommend:
- Better Apify actors (with IDs and links)
- Different architectural approaches
- Third-party services to consider

### **4. Implementation Plan**
Give us:
- Priority order (what to fix first)
- Estimated complexity (easy/medium/hard)
- Testing strategy
- Rollback plan

### **5. Cost/Performance Analysis**
Estimate:
- Cost savings from optimizations
- Performance improvements (speed)
- Expected accuracy gains

---

## 🎯 **Success Criteria**

After implementing your suggestions, we should have:

✅ **95%+ scan success rate** (no rate limit failures)
✅ **80%+ keyword relevance** (posts match criteria)
✅ **50% cost reduction** (less wasted AI calls)
✅ **70%+ location accuracy** (posts from target locations)
✅ **90%+ time accuracy** (posts from last 7-30 days)

---

## 🛠️ **Current Architecture**

```
User Triggers Scan
      ↓
Fetch ALL posts (Apify) ← ISSUE: Rate limits, irrelevant data
      ↓
Send ALL to AI ← ISSUE: Expensive, wasteful
      ↓
Detect signals
      ↓
Create alerts
```

---

## 💡 **Desired Architecture**

```
User Triggers Scan
      ↓
Fetch posts with smart filtering
      ↓
Pre-filter (keywords, time, location) ← ADD THIS
      ↓
Send ONLY relevant posts to AI ← OPTIMIZE
      ↓
Detect signals (higher accuracy)
      ↓
Create high-quality alerts
```

---

## 📊 **Context**

- **System**: Lazarus Protocol (CRM Lead Resurrection)
- **Scale**: Scanning 100+ contacts weekly
- **Budget**: Need to minimize costs
- **Tech**: Python, FastAPI, Apify, OpenAI
- **Timeline**: Need fixes ASAP

---

## 🚀 **How to Analyze**

1. **Start with README.md** - Get full context
2. **Review APIFY_ACTORS.md** - Understand our scrapers
3. **Read the service files** - Understand current implementation
4. **Identify issues** - Find root causes
5. **Suggest fixes** - Provide specific code changes
6. **Recommend alternatives** - Better actors/approaches
7. **Create plan** - Prioritized implementation steps

---

## ❓ **Questions to Answer**

1. Why does `OpenAIApifyTwitterService.py` fail with rate limits?
2. How can we fix keyword filtering in `ApifyLinkedInJobsService.py`?
3. What parameters do these Apify actors actually support?
4. Should we switch to different Apify actors entirely?
5. How to implement location/time filtering efficiently?
6. What pre-filtering should happen before AI analysis?
7. Can we use cheaper AI models for initial screening?
8. What's the best retry strategy for Apify calls?

---

## 📧 **Format Your Response**

Please structure as:

```markdown
# Analysis Report

## Executive Summary
[Brief overview of findings]

## Issue 1: Twitter Rate Limiting
### Root Cause
[Why it's happening]

### Proposed Fix
[Specific code changes]

### Alternative Solutions
[Other approaches]

### Implementation Steps
[How to do it]

## Issue 2: Irrelevant Jobs
[Same structure]

...

## Priority Matrix
1. [Highest priority fix]
2. [Second priority]
...

## Estimated Impact
- Cost reduction: X%
- Speed improvement: X%
- Accuracy gain: X%
```

---

## ⚡ **Important Notes**

- We're using **Apify paid plan** - have budget for API calls
- We prefer **pragmatic solutions** over perfect ones
- **Speed matters** - fixes need to be implementable quickly
- **Backward compatibility** - don't break existing functionality
- **Testing** - provide test cases for each fix

---

## 🙏 **Thank You!**

We're counting on your deep analysis to help us fix these critical issues. Take your time to thoroughly review the code and provide thoughtful, actionable recommendations.

**Our team will implement your suggestions immediately.**

---

**Prepared by**: URI Development Team
**Date**: January 2025
**Package Version**: 1.0
**For**: Claude Opus Diagnostic Analysis

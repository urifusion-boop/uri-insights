# Lazarus Protocol - Exported Files

This folder contains all Lazarus Protocol related files from uri-insights backend.

## Structure

```
lazarus-protocol-export/
├── README.md (this file)
├── Lazarus_Protocol_Diagnostic_Analysis_Report.md (diagnostic report)
├── routers/
│   ├── lazarus_crm_router.py (CRM integration endpoints)
│   ├── lazarus_router.py (main Lazarus API endpoints)
│   └── lazarus_scan_logs.py (scan log endpoints)
├── repository/
│   └── LazarusRepository.py (database layer)
├── domain/schemas/
│   └── lazarus_schema.py (Pydantic schemas)
└── services/
    ├── LazarusService.py (business logic)
    ├── LazarusMonitoringService.py (monitoring & scanning logic)
    └── azure/
        ├── consumers/
        │   └── LazarusMonitoringConsumer.py (queue consumer)
        └── producers/
            └── LazarusMonitoringProducer.py (queue producer)
```

## Components

### 1. API Endpoints (routers/)
- **lazarus_router.py**: Main API endpoints for focus contacts, company monitors, alerts
- **lazarus_crm_router.py**: CRM integration endpoints (HubSpot, Salesforce)
- **lazarus_scan_logs.py**: Endpoints for viewing scan logs and diagnostics

### 2. Database Layer (repository/)
- **LazarusRepository.py**: MongoDB operations for Lazarus data

### 3. Data Models (domain/schemas/)
- **lazarus_schema.py**: Pydantic schemas for validation and serialization

### 4. Business Logic (services/)
- **LazarusService.py**: Core business logic for focus contacts and alerts
- **LazarusMonitoringService.py**: Monitoring logic with 11-signal buying intent detection

### 5. Background Workers (services/azure/)
- **LazarusMonitoringConsumer.py**: Processes monitoring scans from queue
- **LazarusMonitoringProducer.py**: Queues monitoring scans

## Key Features

1. **Focus Contact Monitoring**: Track LinkedIn profiles for buying signals
2. **Company Monitoring**: Track company LinkedIn pages
3. **11-Signal Buying Intent Detection**: AI-powered signal analysis
4. **CRM Integration**: Sync with HubSpot/Salesforce
5. **Alert System**: Real-time notifications for buying signals
6. **Apify Integration**: LinkedIn post scraping with quota management

## Notes

- All files copied from: `/Users/apple/Desktop/URI/uri-insights`
- Date exported: 2026-01-27
- No code modifications made during export
